##
## This script is sourced by /data/data/com.nightmare.code/files/usr/bin/login before executing shell.
##
